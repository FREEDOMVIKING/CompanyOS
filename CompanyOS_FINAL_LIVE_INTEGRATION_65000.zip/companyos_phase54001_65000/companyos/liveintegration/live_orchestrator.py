from companyos.livegate import LiveReadinessGate, OneShotAuthorization
from companyos.transactionops import TransactionLifecycle
from companyos.controlledexec import ControlledExecutionReceipt, PostExecutionLock
from companyos.walletintegration import SolanaExecutionGate
from .runtime_guard import LiveRuntimeGuard
from .receipt_reconciler import ReceiptReconciler
from .live_policy import LiveExecutionPolicy

class FinalLiveExecutionOrchestrator:
    def __init__(self, root, allowlist=None):
        self.root=root
        self.allowlist=set(allowlist or [])
        self.readiness=LiveReadinessGate(root)
        self.auth=OneShotAuthorization(root)
        self.guard=LiveRuntimeGuard(root)
        self.policy=LiveExecutionPolicy()
        self.tx=TransactionLifecycle(
            root,
            max_single_amount=self.policy.max_single,
            min_reserve=self.policy.min_reserve
        )
        self.execgate=SolanaExecutionGate(root, allowlist=self.allowlist)
        self.receipts=ControlledExecutionReceipt(root)
        self.postlock=PostExecutionLock(root)
        self.reconciler=ReceiptReconciler()

    def execute_once(
        self,
        *,
        token,
        destination,
        amount,
        balance,
        estimated_fee,
        memo="controlled live execution"
    ):
        readiness=self.readiness.evaluate()
        if not readiness.get("ready_for_controlled_live_review"):
            return {"success":False,"status":"controlled_live_readiness_not_met","readiness":readiness}

        runtime=self.guard.check()
        if not runtime.get("allowed"):
            return {"success":False,"status":runtime.get("status"),"runtime_guard":runtime}

        amount_check=self.policy.check_amount(amount)
        if not amount_check.get("allowed"):
            return {"success":False,"status":amount_check.get("status"),"policy":amount_check}

        auth=self.auth.validate(token, amount, destination)
        if not auth.get("allowed"):
            return {"success":False,"status":auth.get("status"),"authorization":auth}

        prepared=self.tx.prepare(
            destination=destination,
            amount=amount,
            balance=balance,
            estimated_fee=estimated_fee,
            allowlist=self.allowlist,
            memo=memo
        )
        if not prepared.get("success"):
            return {"success":False,"status":"transaction_preparation_failed","transaction":prepared}

        # The existing Solana gate owns signing + provider-specific execution.
        result=self.execgate.prepare_and_execute(
            amount=amount,
            balance=balance,
            destination=destination,
            source=prepared["proposal"]["source"],
            memo=memo,
            idempotency_key=prepared["fingerprint"],
            dry_run=False,
            signing_authorized=True
        )

        # One-shot auth is consumed after an execution attempt reaches the live gate.
        self.auth.consume()

        receipt=self.receipts.append({
            "mode":"controlled_live",
            "destination":destination,
            "amount":float(amount),
            "execution_result":result
        })

        # Always lock after a live attempt, successful or not.
        lock=self.postlock.engage("controlled_live_attempt_complete")

        return {
            "success": bool(result.get("success")),
            "status": result.get("status"),
            "execution": result,
            "receipt": receipt,
            "post_execution_lock": lock,
            "authorization_consumed": True
        }
